"use client";import{useEffect,useState}from"react";export default function CursorGlow(){const[p,s]=useState({x:0,y:0});
useEffect(()=>{window.addEventListener("mousemove",e=>s({x:e.clientX,y:e.clientY}));},[]);
return(<div className="pointer-events-none fixed w-40 h-40 rounded-full blur-3xl bg-cyan-400 opacity-40 -translate-x-1/2 -translate-y-1/2 transition-all" style={{top:p.y,left:p.x}}/>);}