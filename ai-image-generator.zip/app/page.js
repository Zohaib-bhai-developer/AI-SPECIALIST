"use client";import {useState} from "react";import CursorGlow from "../components/CursorGlow";import NeonButton from "../components/NeonButton";
export default function Home(){const[p,setP]=useState("");const[i,setI]=useState(null);const[l,setL]=useState(false);
async function gen(){setL(true);const r=await fetch("/api/generate",{method:"POST",body:JSON.stringify({prompt:p})});const d=await r.json();setI(`data:image/png;base64,${d.image}`);setL(false);}
return(<main className="relative min-h-screen flex flex-col items-center p-10 bg-grid"><CursorGlow/><h1 className="text-5xl font-bold neon-text mb-10">AI Image Generator</h1>
<textarea className="w-full max-w-xl p-4 bg-black/40 border border-cyan-500 text-white rounded-lg" rows="3" placeholder="Enter prompt..." value={p} onChange={e=>setP(e.target.value)}/>
<div className="mt-4" onClick={gen}><NeonButton>{l?"Generating...":"Generate"}</NeonButton></div>
{i&&<img src={i} className="mt-10 w-[400px] rounded-lg shadow-[0_0_25px_#00eaff]"/>}</main>);}
