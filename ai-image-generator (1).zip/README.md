# Free AI Image Generator

- Generates AI images using text prompts (SDXL model via Replicate API)
- Backend: Node.js + Express
- Frontend: HTML, CSS, JS
- Deploy: Vercel